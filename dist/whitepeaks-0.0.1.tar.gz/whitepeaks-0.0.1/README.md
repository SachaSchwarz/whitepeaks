WHITEPEAKS - QOQILab
====================
Ultrafast Quantum Optics Package containing phase retrieval algorithms using
-   FROG: frequency-resolved optical gating
-   XFROG: cross-correlation frequency-resolved optival gating
-   GS: Gerchberg-Saxton algorithm

Content
---------

