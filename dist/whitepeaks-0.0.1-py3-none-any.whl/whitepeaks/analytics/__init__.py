'''
Initialize analytics subpackage
'''

from .fft import *
from .fitGaussian import *
from .fitPolynomial import *
from .functions import *
from .stats import *



